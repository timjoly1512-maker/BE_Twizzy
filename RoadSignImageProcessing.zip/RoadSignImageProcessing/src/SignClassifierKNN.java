import org.opencv.core.Core;
import org.opencv.core.CvType;
import org.opencv.core.Mat;
import org.opencv.core.Size;
import org.opencv.imgcodecs.Imgcodecs;
import org.opencv.imgproc.Imgproc;
import org.opencv.ml.KNearest;
import org.opencv.ml.Ml;

import java.io.File;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;

public class SignClassifierKNN {

	private static final int IMAGE_SIZE = 48;
	private static final int K = 5;
	private static final int MAX_IMAGES_PER_CLASS = 10000;

   
    

    private static ArrayList<String> idToLabel = new ArrayList<String>();
    private static HashMap<String, Integer> labelToId = new HashMap<String, Integer>();

    public static void main(String[] args) {
        System.loadLibrary(Core.NATIVE_LIBRARY_NAME);

        String trainPath = "dataset_filtered/train";
        String testPath = "dataset_filtered/test";

        System.out.println("Chargement des classes...");
        chargerClasses(trainPath);

        System.out.println("Nombre de classes : " + idToLabel.size());

        System.out.println("\nChargement des images d'entraînement...");
        ArrayList<ImageSample> trainSamples = chargerImages(trainPath, true);

        System.out.println("Images utilisées pour l'entraînement : " + trainSamples.size());

        if (trainSamples.size() == 0) {
            System.out.println("Aucune image d'entraînement trouvée.");
            return;
        }

        System.out.println("\nCréation des matrices OpenCV...");
        Mat trainData = new Mat(trainSamples.size(), IMAGE_SIZE * IMAGE_SIZE, CvType.CV_32F);
        Mat trainLabels = new Mat(trainSamples.size(), 1, CvType.CV_32F);

        for (int i = 0; i < trainSamples.size(); i++) {
            ImageSample sample = trainSamples.get(i);

            Mat feature = imageToFeature(sample.file);

            if (feature.empty()) {
                continue;
            }

            feature.copyTo(trainData.row(i));
            trainLabels.put(i, 0, sample.labelId);
        }

        System.out.println("Entraînement du modèle KNN...");
        KNearest knn = KNearest.create();
        knn.setDefaultK(K);
        knn.setIsClassifier(true);

        boolean trained = knn.train(trainData, Ml.ROW_SAMPLE, trainLabels);

        if (!trained) {
            System.out.println("Erreur : le modèle KNN n'a pas été entraîné.");
            return;
        }

        System.out.println("Modèle KNN entraîné avec succès.");

        System.out.println("\nTest du modèle...");
        testerModele(knn, testPath);

        System.out.println("\nTest sur une image unique...");
        predireImageUnique(knn, "dataset_filtered/test/Stop/00014_00007_00002_png.rf.fc8f4dda18282b867760ece159f2525c.jpg");

        System.out.println("\nProgramme terminé.");
    }
    public static void predireImageUnique(KNearest knn, String imagePath) {
        File imageFile = new File(imagePath);

        if (!imageFile.exists()) {
            System.out.println("Image introuvable : " + imagePath);
            return;
        }

        Mat feature = imageToFeature(imageFile);

        if (feature.empty()) {
            System.out.println("Impossible de lire l'image : " + imagePath);
            return;
        }

        Mat results = new Mat();
        float prediction = knn.findNearest(feature, K, results);

        int predictedId = Math.round(prediction);

        if (predictedId >= 0 && predictedId < idToLabel.size()) {
            String predictedLabel = idToLabel.get(predictedId);

            System.out.println("Image testée : " + imageFile.getName());
            System.out.println("Classe prédite : " + predictedLabel);
        } else {
            System.out.println("Classe prédite inconnue.");
        }
    }

    public static void chargerClasses(String trainPath) {
        File trainFolder = new File(trainPath);

        if (!trainFolder.exists()) {
            System.out.println("Dossier introuvable : " + trainFolder.getAbsolutePath());
            return;
        }

        File[] classFolders = trainFolder.listFiles();

        if (classFolders == null) {
            return;
        }

        ArrayList<String> labels = new ArrayList<String>();

        for (File folder : classFolders) {
            if (folder.isDirectory()) {
                labels.add(folder.getName());
            }
        }

        Collections.sort(labels);

        for (int i = 0; i < labels.size(); i++) {
            String label = labels.get(i);
            idToLabel.add(label);
            labelToId.put(label, i);
        }
    }

    public static ArrayList<ImageSample> chargerImages(String splitPath, boolean limiterParClasse) {
        ArrayList<ImageSample> samples = new ArrayList<ImageSample>();

        File splitFolder = new File(splitPath);

        if (!splitFolder.exists()) {
            System.out.println("Dossier introuvable : " + splitFolder.getAbsolutePath());
            return samples;
        }

        File[] classFolders = splitFolder.listFiles();

        if (classFolders == null) {
            return samples;
        }

        for (File classFolder : classFolders) {
            if (!classFolder.isDirectory()) {
                continue;
            }

            String label = classFolder.getName();

            if (!labelToId.containsKey(label)) {
                continue;
            }

            int labelId = labelToId.get(label);

            File[] imageFiles = classFolder.listFiles();

            if (imageFiles == null) {
                continue;
            }

            int countForClass = 0;

            for (File imageFile : imageFiles) {
                if (!estImage(imageFile)) {
                    continue;
                }

                samples.add(new ImageSample(imageFile, labelId));
                countForClass++;

                if (limiterParClasse && countForClass >= MAX_IMAGES_PER_CLASS) {
                    break;
                }
            }
        }

        return samples;
    }

    public static Mat imageToFeature(File imageFile) {
        Mat image = Imgcodecs.imread(imageFile.getAbsolutePath());

        if (image.empty()) {
            return new Mat();
        }

        Mat resized = new Mat();
        Imgproc.resize(image, resized, new Size(IMAGE_SIZE, IMAGE_SIZE));

        Mat gray = new Mat();
        Imgproc.cvtColor(resized, gray, Imgproc.COLOR_BGR2GRAY);

        Imgproc.equalizeHist(gray, gray);

        Mat floatImage = new Mat();
        gray.convertTo(floatImage, CvType.CV_32F, 1.0 / 255.0);

        Mat feature = floatImage.reshape(1, 1);

        return feature;
    }

    public static void testerModele(KNearest knn, String testPath) {
        ArrayList<ImageSample> testSamples = chargerImages(testPath, false);

        if (testSamples.size() == 0) {
            System.out.println("Aucune image de test trouvée.");
            return;
        }

        int total = 0;
        int correct = 0;

        File reportFolder = new File("knn_results");
        reportFolder.mkdirs();

        File reportFile = new File(reportFolder, "predictions.csv");

        try {
            PrintWriter writer = new PrintWriter(reportFile);
            writer.println("filename,true_label,predicted_label,result");

            for (ImageSample sample : testSamples) {
                Mat feature = imageToFeature(sample.file);

                if (feature.empty()) {
                    continue;
                }

                Mat results = new Mat();
                float prediction = knn.findNearest(feature, K, results);

                int predictedId = Math.round(prediction);

                String trueLabel = idToLabel.get(sample.labelId);
                String predictedLabel = "UNKNOWN";

                if (predictedId >= 0 && predictedId < idToLabel.size()) {
                    predictedLabel = idToLabel.get(predictedId);
                }

                boolean isCorrect = predictedId == sample.labelId;

                if (isCorrect) {
                    correct++;
                }

                total++;

                writer.println(
                        sample.file.getName() + ","
                                + trueLabel + ","
                                + predictedLabel + ","
                                + (isCorrect ? "OK" : "ERREUR")
                );
            }

            writer.close();

        } catch (Exception e) {
            System.out.println("Erreur pendant la création du rapport de prédiction.");
            e.printStackTrace();
            return;
        }

        double accuracy = 0.0;

        if (total > 0) {
            accuracy = (100.0 * correct) / total;
        }

        System.out.println("Images testées : " + total);
        System.out.println("Prédictions correctes : " + correct);
        System.out.println("Précision : " + accuracy + " %");
        System.out.println("Rapport créé : " + reportFile.getAbsolutePath());
    }

    public static boolean estImage(File file) {
        String name = file.getName().toLowerCase();

        return name.endsWith(".jpg")
                || name.endsWith(".jpeg")
                || name.endsWith(".png");
    }

    static class ImageSample {
        File file;
        int labelId;

        ImageSample(File file, int labelId) {
            this.file = file;
            this.labelId = labelId;
        }
    }
}