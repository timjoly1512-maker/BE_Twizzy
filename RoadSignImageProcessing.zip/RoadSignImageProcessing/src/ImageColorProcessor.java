import org.opencv.core.Core;
import org.opencv.core.Mat;
import org.opencv.core.Scalar;
import org.opencv.imgcodecs.Imgcodecs;
import org.opencv.imgproc.Imgproc;

import java.io.File;

public class ImageColorProcessor {

    public static void main(String[] args) {
        System.loadLibrary(Core.NATIVE_LIBRARY_NAME);

        String imagePath = "dataset/train/-_jpg.rf.b3cfdb9b7326c28526c55ebba2d3787a.jpg";

        Mat image = Imgcodecs.imread(imagePath);

        if (image.empty()) {
            System.out.println("Erreur : image non lue. Vérifie le chemin.");
            return;
        }

        File outputFolder = new File("results");
        outputFolder.mkdirs();

        Mat hsv = new Mat();
        Imgproc.cvtColor(image, hsv, Imgproc.COLOR_BGR2HSV);

        Mat redMask1 = new Mat();
        Mat redMask2 = new Mat();
        Mat redMask = new Mat();

        Core.inRange(hsv, new Scalar(0, 110, 50), new Scalar(6, 255, 255), redMask1);
        Core.inRange(hsv, new Scalar(170, 110, 50), new Scalar(180, 255, 255), redMask2);
        Core.bitwise_or(redMask1, redMask2, redMask);

        Mat yellowMask = new Mat();
        Core.inRange(hsv, new Scalar(20, 80, 80), new Scalar(35, 255, 255), yellowMask);

        Mat blueMask = new Mat();
        Core.inRange(hsv, new Scalar(90, 80, 50), new Scalar(130, 255, 255), blueMask);

        Imgcodecs.imwrite("results/original.jpg", image);
        Imgcodecs.imwrite("results/red_mask.jpg", redMask);
        Imgcodecs.imwrite("results/yellow_mask.jpg", yellowMask);
        Imgcodecs.imwrite("results/blue_mask.jpg", blueMask);

        int redPixels = Core.countNonZero(redMask);
        int yellowPixels = Core.countNonZero(yellowMask);
        int bluePixels = Core.countNonZero(blueMask);

        System.out.println("Traitement terminé.");
        System.out.println("Image originale sauvegardée : results/original.jpg");
        System.out.println("Masque rouge sauvegardé : results/red_mask.jpg");
        System.out.println("Masque jaune sauvegardé : results/yellow_mask.jpg");
        System.out.println("Masque bleu sauvegardé : results/blue_mask.jpg");

        System.out.println("\nPixels rouges détectés : " + redPixels);
        System.out.println("Pixels jaunes détectés : " + yellowPixels);
        System.out.println("Pixels bleus détectés : " + bluePixels);
    }
}