import org.opencv.core.Core;
import org.opencv.core.Mat;
import org.opencv.imgcodecs.Imgcodecs;

public class OpenCVTest {

    public static void main(String[] args) {
        System.loadLibrary(Core.NATIVE_LIBRARY_NAME);

        String imagePath = "dataset/train/-_jpg.rf.b3cfdb9b7326c28526c55ebba2d3787a.jpg";

        Mat image = Imgcodecs.imread(imagePath);

        if (image.empty()) {
            System.out.println("Image non lue. Vérifie le chemin de l'image.");
        } else {
            System.out.println("OpenCV fonctionne.");
            System.out.println("Largeur : " + image.cols());
            System.out.println("Hauteur : " + image.rows());
            System.out.println("Canaux : " + image.channels());
        }
    }
}