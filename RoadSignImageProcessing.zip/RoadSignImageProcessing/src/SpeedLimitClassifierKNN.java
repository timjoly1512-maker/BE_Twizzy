import org.opencv.core.Core;
import org.opencv.core.CvType;
import org.opencv.core.Mat;
import org.opencv.core.Rect;
import org.opencv.core.Size;
import org.opencv.imgcodecs.Imgcodecs;
import org.opencv.imgproc.Imgproc;
import org.opencv.ml.KNearest;
import org.opencv.ml.Ml;
import org.opencv.core.Point;
import org.opencv.core.MatOfPoint;
import java.util.List;
import org.opencv.core.Scalar;

import java.io.File;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;

public class SpeedLimitClassifierKNN {

    private static final int BASE_SIZE = 128;
    private static final int FEATURE_SIZE = 96;
    private static final int K = 1;

    private static ArrayList<String> idToLabel = new ArrayList<String>();
    private static HashMap<String, Integer> labelToId = new HashMap<String, Integer>();

    public static void main(String[] args) {
        System.loadLibrary(Core.NATIVE_LIBRARY_NAME);

        String trainPath = "dataset_filtered/train";

        // Ton image externe à tester
        String imageToPredict = "external_images/ref70.jpg";

        System.out.println("Chargement des classes de limitation de vitesse...");
        chargerClassesSpeedLimit(trainPath);

        System.out.println("Classes utilisées : " + idToLabel.size());

        for (String label : idToLabel) {
            System.out.println("- " + label);
        }

        System.out.println("\nChargement des images d'entraînement...");
        ArrayList<ImageSample> trainSamples = chargerImagesTrain(trainPath);

        System.out.println("Images utilisées pour l'entraînement : " + trainSamples.size());

        if (trainSamples.size() == 0) {
            System.out.println("Aucune image d'entraînement trouvée.");
            return;
        }

        Mat trainData = new Mat(trainSamples.size(), FEATURE_SIZE * FEATURE_SIZE, CvType.CV_32F);
        Mat trainLabels = new Mat(trainSamples.size(), 1, CvType.CV_32F);

        for (int i = 0; i < trainSamples.size(); i++) {
            ImageSample sample = trainSamples.get(i);

            Mat feature = imageToFeature(sample.file);

            if (!feature.empty()) {
                feature.copyTo(trainData.row(i));
                trainLabels.put(i, 0, sample.labelId);
            }
        }

        System.out.println("\nEntraînement du modèle KNN spécialisé vitesse...");
        KNearest knn = KNearest.create();
        knn.setDefaultK(K);
        knn.setIsClassifier(true);

        boolean trained = knn.train(trainData, Ml.ROW_SAMPLE, trainLabels);

        if (!trained) {
            System.out.println("Erreur : le modèle n'a pas été entraîné.");
            return;
        }

        System.out.println("Modèle entraîné avec succès.");

        System.out.println("\nPrédiction de l'image externe...");
        predireImage(knn, imageToPredict);

        System.out.println("\nProgramme terminé.");
    }

    public static void chargerClassesSpeedLimit(String trainPath) {
        File trainFolder = new File(trainPath);

        if (!trainFolder.exists()) {
            System.out.println("Dossier train introuvable : " + trainFolder.getAbsolutePath());
            return;
        }

        File[] classFolders = trainFolder.listFiles();

        if (classFolders == null) {
            return;
        }

        ArrayList<String> labels = new ArrayList<String>();

        for (File folder : classFolders) {
            if (folder.isDirectory() && folder.getName().startsWith("Speed_limit_")) {
                labels.add(folder.getName());
            }
        }

        Collections.sort(labels);

        for (int i = 0; i < labels.size(); i++) {
            String label = labels.get(i);
            idToLabel.add(label);
            labelToId.put(label, i);
        }
    }

    public static ArrayList<ImageSample> chargerImagesTrain(String trainPath) {
        ArrayList<ImageSample> samples = new ArrayList<ImageSample>();

        File trainFolder = new File(trainPath);
        File[] classFolders = trainFolder.listFiles();

        if (classFolders == null) {
            return samples;
        }

        for (File classFolder : classFolders) {
            if (!classFolder.isDirectory()) {
                continue;
            }

            String label = classFolder.getName();

            if (!labelToId.containsKey(label)) {
                continue;
            }

            int labelId = labelToId.get(label);

            File[] imageFiles = classFolder.listFiles();

            if (imageFiles == null) {
                continue;
            }

            for (File imageFile : imageFiles) {
                if (estImage(imageFile)) {
                    samples.add(new ImageSample(imageFile, labelId));
                }
            }
        }

        return samples;
    }

    public static void predireImage(KNearest knn, String imagePath) {
        File imageFile = new File(imagePath);

        if (!imageFile.exists()) {
            System.out.println("Image introuvable : " + imagePath);
            return;
        }

        Mat feature = imageToFeature(imageFile);

        if (feature.empty()) {
            System.out.println("Impossible de lire l'image : " + imagePath);
            return;
        }

        Mat results = new Mat();
        float prediction = knn.findNearest(feature, K, results);

        int predictedId = Math.round(prediction);

        String predictedLabel = "UNKNOWN";

        if (predictedId >= 0 && predictedId < idToLabel.size()) {
            predictedLabel = idToLabel.get(predictedId);
        }

        System.out.println("--------------------------------");
        System.out.println("Image testée : " + imageFile.getName());
        System.out.println("Classe prédite : " + predictedLabel);
    }

    public static Mat imageToFeature(File imageFile) {
        Mat image = Imgcodecs.imread(imageFile.getAbsolutePath());

        if (image.empty()) {
            return new Mat();
        }

        Mat resized = new Mat();
        Imgproc.resize(image, resized, new Size(BASE_SIZE, BASE_SIZE));

        /*
         * On garde seulement la zone centrale du panneau.
         * Cela évite de prendre le cercle rouge extérieur.
         */
        Rect centerRoi = new Rect(22, 28, 84, 68);
        Mat center = new Mat(resized, centerRoi);

        /*
         * Conversion HSV.
         * Les chiffres noirs ont une faible luminosité et une faible saturation.
         * Le cercle rouge a une forte saturation, donc il est mieux éliminé.
         */
        Mat hsv = new Mat();
        Imgproc.cvtColor(center, hsv, Imgproc.COLOR_BGR2HSV);

        Mat blackMask = new Mat();

        Core.inRange(
                hsv,
                new Scalar(0, 0, 0),
                new Scalar(180, 120, 130),
                blackMask
        );

        /*
         * Nettoyage léger du masque.
         */
        Mat kernel = Imgproc.getStructuringElement(
                Imgproc.MORPH_RECT,
                new Size(2, 2)
        );

        Imgproc.morphologyEx(
                blackMask,
                blackMask,
                Imgproc.MORPH_OPEN,
                kernel
        );

        Mat finalImage = new Mat();
        Imgproc.resize(blackMask, finalImage, new Size(FEATURE_SIZE, FEATURE_SIZE));

        /*
         * Sauvegarde debug pour voir exactement ce que le modèle regarde.
         */
        File debugFolder = new File("debug_speed");
        debugFolder.mkdirs();

        String debugName = "blackdigits_" + imageFile.getName();
        Imgcodecs.imwrite(new File(debugFolder, debugName).getAbsolutePath(), finalImage);

        Mat floatImage = new Mat();
        finalImage.convertTo(floatImage, CvType.CV_32F, 1.0 / 255.0);

        return floatImage.reshape(1, 1);
    }
    public static Rect unionRects(Rect a, Rect b) {
        int x1 = Math.min(a.x, b.x);
        int y1 = Math.min(a.y, b.y);
        int x2 = Math.max(a.x + a.width, b.x + b.width);
        int y2 = Math.max(a.y + a.height, b.y + b.height);

        return new Rect(x1, y1, x2 - x1, y2 - y1);
    }

    public static boolean estImage(File file) {
        String name = file.getName().toLowerCase();

        return name.endsWith(".jpg")
                || name.endsWith(".jpeg")
                || name.endsWith(".png");
    }

    static class ImageSample {
        File file;
        int labelId;

        ImageSample(File file, int labelId) {
            this.file = file;
            this.labelId = labelId;
        }
    }
}