import org.opencv.core.Core;
import org.opencv.core.CvType;
import org.opencv.core.Mat;
import org.opencv.core.Size;
import org.opencv.imgcodecs.Imgcodecs;
import org.opencv.imgproc.Imgproc;
import org.opencv.ml.KNearest;
import org.opencv.ml.Ml;

import java.io.File;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;

public class SingleImagePrediction {

    private static final int IMAGE_SIZE = 48;
    private static final int K = 5;

    private static ArrayList<String> idToLabel = new ArrayList<String>();
    private static HashMap<String, Integer> labelToId = new HashMap<String, Integer>();

    public static void main(String[] args) {
        System.loadLibrary(Core.NATIVE_LIBRARY_NAME);

        String trainPath = "dataset_filtered/train";

        // Change seulement cette ligne pour tester une autre image.
        String imageToPredict = "dataset_filtered/test/Speed_limit_70_km_h/video1_frame_0170_jpg.rf.637e4dc93de1fd790d91451880d9696f.jpg";

        System.out.println("Chargement des classes...");
        chargerClasses(trainPath);

        System.out.println("Nombre de classes : " + idToLabel.size());

        System.out.println("Chargement des images d'entraînement...");
        ArrayList<ImageSample> trainSamples = chargerImages(trainPath);

        System.out.println("Images utilisées pour l'entraînement : " + trainSamples.size());

        if (trainSamples.size() == 0) {
            System.out.println("Aucune image d'entraînement trouvée.");
            return;
        }

        Mat trainData = new Mat(trainSamples.size(), IMAGE_SIZE * IMAGE_SIZE, CvType.CV_32F);
        Mat trainLabels = new Mat(trainSamples.size(), 1, CvType.CV_32F);

        for (int i = 0; i < trainSamples.size(); i++) {
            ImageSample sample = trainSamples.get(i);
            Mat feature = imageToFeature(sample.file);

            if (!feature.empty()) {
                feature.copyTo(trainData.row(i));
                trainLabels.put(i, 0, sample.labelId);
            }
        }

        System.out.println("Entraînement du modèle KNN...");
        KNearest knn = KNearest.create();
        knn.setDefaultK(K);
        knn.setIsClassifier(true);

        boolean trained = knn.train(trainData, Ml.ROW_SAMPLE, trainLabels);

        if (!trained) {
            System.out.println("Erreur : le modèle n'a pas été entraîné.");
            return;
        }

        System.out.println("Modèle entraîné avec succès.");

        System.out.println("\nPrédiction de l'image :");
        predireImage(knn, imageToPredict);
    }

    public static void chargerClasses(String trainPath) {
        File trainFolder = new File(trainPath);

        File[] classFolders = trainFolder.listFiles();

        if (classFolders == null) {
            return;
        }

        ArrayList<String> labels = new ArrayList<String>();

        for (File folder : classFolders) {
            if (folder.isDirectory()) {
                labels.add(folder.getName());
            }
        }

        Collections.sort(labels);

        for (int i = 0; i < labels.size(); i++) {
            String label = labels.get(i);
            idToLabel.add(label);
            labelToId.put(label, i);
        }
    }

    public static ArrayList<ImageSample> chargerImages(String splitPath) {
        ArrayList<ImageSample> samples = new ArrayList<ImageSample>();

        File splitFolder = new File(splitPath);

        File[] classFolders = splitFolder.listFiles();

        if (classFolders == null) {
            return samples;
        }

        for (File classFolder : classFolders) {
            if (!classFolder.isDirectory()) {
                continue;
            }

            String label = classFolder.getName();

            if (!labelToId.containsKey(label)) {
                continue;
            }

            int labelId = labelToId.get(label);

            File[] imageFiles = classFolder.listFiles();

            if (imageFiles == null) {
                continue;
            }

            for (File imageFile : imageFiles) {
                if (estImage(imageFile)) {
                    samples.add(new ImageSample(imageFile, labelId));
                }
            }
        }

        return samples;
    }

    public static void predireImage(KNearest knn, String imagePath) {
        File imageFile = new File(imagePath);

        if (!imageFile.exists()) {
            System.out.println("Image introuvable : " + imagePath);
            return;
        }

        Mat feature = imageToFeature(imageFile);

        if (feature.empty()) {
            System.out.println("Impossible de lire l'image.");
            return;
        }

        Mat results = new Mat();
        float prediction = knn.findNearest(feature, K, results);

        int predictedId = Math.round(prediction);

        if (predictedId >= 0 && predictedId < idToLabel.size()) {
            System.out.println("Image testée : " + imageFile.getName());
            System.out.println("Classe prédite : " + idToLabel.get(predictedId));
        } else {
            System.out.println("Classe inconnue.");
        }
    }

    public static Mat imageToFeature(File imageFile) {
        Mat image = Imgcodecs.imread(imageFile.getAbsolutePath());

        if (image.empty()) {
            return new Mat();
        }

        Mat resized = new Mat();
        Imgproc.resize(image, resized, new Size(IMAGE_SIZE, IMAGE_SIZE));

        Mat gray = new Mat();
        Imgproc.cvtColor(resized, gray, Imgproc.COLOR_BGR2GRAY);

        Imgproc.equalizeHist(gray, gray);

        Mat floatImage = new Mat();
        gray.convertTo(floatImage, CvType.CV_32F, 1.0 / 255.0);

        return floatImage.reshape(1, 1);
    }

    public static boolean estImage(File file) {
        String name = file.getName().toLowerCase();

        return name.endsWith(".jpg")
                || name.endsWith(".jpeg")
                || name.endsWith(".png");
    }

    static class ImageSample {
        File file;
        int labelId;

        ImageSample(File file, int labelId) {
            this.file = file;
            this.labelId = labelId;
        }
    }
}