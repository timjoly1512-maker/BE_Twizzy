# Road Sign Image Processing - Java OpenCV

## Objectif

Ce projet correspond à la partie traitement d’images du projet de détection de panneaux de signalisation.

L’objectif est de préparer une base d’images exploitable pour la suite du projet, en utilisant Java et OpenCV.

La base de données fournie contient trois sous-dossiers :

- `train`
- `valid`
- `test`

Chaque dossier contient un fichier `_classes.csv` associant chaque image à un ou plusieurs labels.

## Travail réalisé

### 1. Analyse de la base de données

Une première classe `DatasetAnalyzer.java` permet de lire les fichiers `_classes.csv` et de compter :

- le nombre total d’images ;
- le nombre d’images avec un seul label ;
- le nombre d’images sans label ;
- le nombre d’images avec plusieurs labels ;
- la répartition des images par classe.

### 2. Intégration d’OpenCV avec Java

OpenCV a été lié au projet Eclipse.  
Un premier test a permis de vérifier que Java peut lire une image avec OpenCV.

Résultat du test :

- largeur : 640 pixels ;
- hauteur : 640 pixels ;
- nombre de canaux : 3.

### 3. Prétraitement couleur

Une classe `ImageColorProcessor.java` permet de lire une image, de la convertir de BGR vers HSV, puis de créer des masques de couleur :

- masque rouge ;
- masque jaune ;
- masque bleu.

Cette étape permet de vérifier les zones de couleur présentes dans une image.

### 4. Filtrage automatique de la base

La classe `DatasetFilterOpenCV.java` permet de filtrer automatiquement les images.

Les critères utilisés sont :

- garder uniquement les images avec un seul label ;
- ignorer les images sans label ;
- ignorer les images avec plusieurs labels ;
- exclure certaines classes non prioritaires pour notre étude ;
- vérifier que l’image est lisible avec OpenCV ;
- convertir l’image en HSV ;
- détecter la présence de couleurs utiles : rouge, jaune, bleu ou vert ;
- copier les images retenues dans un nouveau dossier `dataset_filtered`.

## Résultats du filtrage

### Train

- Images dans le CSV : 12 754
- Images sans label : 3 332
- Images avec plusieurs labels : 1 434
- Classes exclues : 36
- Images illisibles/introuvables : 0
- Images sans couleur utile : 1 088
- Images retenues : 6 864

### Validation

- Images dans le CSV : 1 151
- Images sans label : 206
- Images avec plusieurs labels : 180
- Classes exclues : 9
- Images illisibles/introuvables : 0
- Images sans couleur utile : 87
- Images retenues : 669

### Test

- Images dans le CSV : 990
- Images sans label : 209
- Images avec plusieurs labels : 161
- Classes exclues : 6
- Images illisibles/introuvables : 0
- Images sans couleur utile : 95
- Images retenues : 519

## Résultat global

La base originale contient 14 895 images.

Après filtrage, 8 052 images ont été retenues :

- 6 864 images pour l’entraînement ;
- 669 images pour la validation ;
- 519 images pour le test.

## Conclusion

Cette partie du projet prépare une base d’images plus propre et plus exploitable pour la suite.

Le travail réalisé permet de passer d’une base brute Roboflow à une base filtrée, organisée et compatible avec une chaîne de traitement d’images Java/OpenCV.