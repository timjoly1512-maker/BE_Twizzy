# Installation et préparation de la base de données

## 1. Objectif

Ce document explique comment placer la base de données dans le projet avant de lancer les programmes Java/OpenCV.

La base de données ne doit pas forcément être mise directement sur GitHub car elle contient beaucoup d’images et peut être lourde.  
Chaque personne qui utilise le projet doit d’abord récupérer la base, puis la placer au bon endroit.

## 2. Structure attendue

La base de données brute doit être placée dans un dossier appelé :  dataset